function showPopup(popupId) {
    document.getElementById(popupId).style.display = 'flex';
}

function hidePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
}

// Function to show the subscription popup
function showSubscriptionPopup(message) {
    var subscriptionPopup = document.getElementById('subscriptionPopup');
    subscriptionPopup.innerHTML = message;
    subscriptionPopup.style.display = 'block';
    setTimeout(function () {
        subscriptionPopup.style.display = 'none';
    }, 3000); // Adjust the timeout (in milliseconds) as needed
}

// Function to handle form submission
function handleSubscriptionSubmit(event) {
    event.preventDefault(); // Prevent the default form submission behavior
    // Additional logic for form submission (e.g., sending data to the server)

    // Show the thank you message
    showSubscriptionPopup('Thank you for subscribing!');
}

// Attach the event listener to the subscription form
document.getElementById('subscribeForm').addEventListener('submit', handleSubscriptionSubmit);

