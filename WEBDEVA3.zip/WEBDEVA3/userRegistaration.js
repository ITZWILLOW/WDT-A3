function showPopup(popupId) {
    document.getElementById(popupId).style.display = 'flex';
}

function hidePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
}
// Add these functions to your userRegistaration.js file or include them directly in your HTML

function showThankYouPopup() {
    showPopup('thankYouPopup');
  }
  
  function hidePopup(popupId) {
    document.getElementById(popupId).style.display = 'none';
  }
  
  function showPopup(popupId) {
    document.getElementById(popupId).style.display = 'flex';
  }
  