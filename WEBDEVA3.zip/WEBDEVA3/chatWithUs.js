document.getElementById('sendButton').addEventListener('click', function() {
    // Check if agents are available (you can replace this with your logic)
    const agentsAvailable = false;
  
    if (!agentsAvailable) {
      showPopup('unavailablePopup');
    } else {
      // Perform the logic to send the message (e.g., AJAX request)
      const userMessage = document.getElementById('messageInput').value;
      sendMessage(userMessage);
  
      // Clear the input after sending the message
      document.getElementById('messageInput').value = '';
    }
  });
  
  // Function to send the message (replace this with your actual implementation)
  function sendMessage(message) {
    // Your logic to send the message (e.g., AJAX request)
    console.log('Message sent:', message);
  }
  
  // Optional: Add a function to close the pop-up
  function closeUnavailablePopup() {
    hidePopup('unavailablePopup');
  }